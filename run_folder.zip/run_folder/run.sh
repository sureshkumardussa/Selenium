
  java -Dfile.encoding=utf-8 -cp ./signals.jar org.testng.TestNG single.xml



